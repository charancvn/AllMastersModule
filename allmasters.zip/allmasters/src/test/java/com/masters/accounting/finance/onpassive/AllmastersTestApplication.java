package com.masters.accounting.finance.onpassive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AllmastersTestApplication {

	@Test
	void contextLoads() {
	}

}
