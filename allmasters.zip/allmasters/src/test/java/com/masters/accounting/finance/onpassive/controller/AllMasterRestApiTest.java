package com.masters.accounting.finance.onpassive.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.masters.accounting.finance.onpassive.entity.AddColumnResoponse;
import com.masters.accounting.finance.onpassive.service.AllMastersService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = AllMastersController.class)
public class AllMasterRestApiTest {

	@Autowired
	MockMvc mockMvc;

	@MockBean
	AllMastersService service;

	@Test
	public void getAllColumnsTest() throws Exception {

		String tableName = "allmasters";
		MockHttpServletRequestBuilder getReq = MockMvcRequestBuilders
				.get("/allmasters/getColumns?tableName='" + tableName + "'");

		MvcResult result = mockMvc.perform(getReq).andReturn();

		MockHttpServletResponse response = result.getResponse();

		int status = response.getStatus();

		assertEquals(200, status);
	}

	@Test
	public void getAllColumnsWithOutParameterTest() throws Exception {
		String tableName = "";
		MockHttpServletRequestBuilder getReq = MockMvcRequestBuilders
				.get("/allmasters/getColumns?tableName='" + tableName + "'");

		MvcResult result = mockMvc.perform(getReq).andReturn();

		MockHttpServletResponse response2 = result.getResponse();

		int status = response2.getStatus();

		assertEquals(200, status);
	}

	@Test
	public void creatAddColumn() throws Exception {

		AddColumnResoponse serviceResponse = new AddColumnResoponse();
		when(service.createColumnMasters(Mockito.any(), Mockito.anyString())).thenReturn(serviceResponse);
		MockHttpServletRequestBuilder getReq = MockMvcRequestBuilders.post("/allmasters/addcolumn")
				.param("tableName", "allmasters").param("columnName", "desc12");
		MvcResult result = mockMvc.perform(getReq).andReturn();
		MockHttpServletResponse response = result.getResponse();
		int status = response.getStatus();
		assertEquals(200, status);

	}

	@Test
	public void creatAddIntegerColumn() throws Exception {

		int columnName = 3;
		String tableName = "allmasters";
		AddColumnResoponse serviceResponse = new AddColumnResoponse();
		when(service.integerCreateColumnMasters(Mockito.any(), Mockito.anyInt())).thenReturn(serviceResponse);
		MockHttpServletRequestBuilder getReq = MockMvcRequestBuilders.post("/allmasters/addintegercolumn?tableName='"+tableName+"'&columnName=1");
		MvcResult result = mockMvc.perform(getReq).andReturn();
		MockHttpServletResponse response = result.getResponse();
		int status = response.getStatus();
		assertEquals(200, status);

	}

	@Test
	public void updateColumn() throws Exception {

		AddColumnResoponse serviceResponse = new AddColumnResoponse();
		when(service.createColumnMasters(Mockito.any(), Mockito.anyString())).thenReturn(serviceResponse);
		MockHttpServletRequestBuilder getReq = MockMvcRequestBuilders.put("/allmasters/updateColumn")
				.param("tableName", "allmasters").param("oldColumName", "desc12")
				.param("newColumName", "newColumName123");
		MvcResult result = mockMvc.perform(getReq).andReturn();
		MockHttpServletResponse response = result.getResponse();
		int status = response.getStatus();
		assertEquals(200, status);

	}
	
	@Test
	public void updateIntegerColumn() throws Exception {

		String tableName = "allmasters";
		AddColumnResoponse serviceResponse = new AddColumnResoponse();
		when(service.integerCreateColumnMasters(Mockito.any(), Mockito.anyInt())).thenReturn(serviceResponse);
		MockHttpServletRequestBuilder getReq = MockMvcRequestBuilders.put("/allmasters/updateIntegerColumn?tableName='"+tableName+"'&oldColumName=1&newColumName=2");
		MvcResult result = mockMvc.perform(getReq).andReturn();
		MockHttpServletResponse response = result.getResponse();
		int status = response.getStatus();
		assertEquals(200, status);

	}

	@Test
	public void deleteColumnTest() throws Exception {
		String columnName = "sdfsfsf";
		String tableName = "allmasters";
		MockHttpServletRequestBuilder getReq = MockMvcRequestBuilders
				.delete("/allmasters/deleteColumn?columnName='" + columnName + "'&tableName='" + tableName + "'");

		MvcResult result = mockMvc.perform(getReq).andReturn();

		MockHttpServletResponse response2 = result.getResponse();

		int status = response2.getStatus();

		assertEquals(200, status);
	}

	@Test
	public void deleteIntegerColumnTest() throws Exception {
		int columnName = 23;
		String tableName = "allmasters";
		MockHttpServletRequestBuilder getReq = MockMvcRequestBuilders
				.delete("/allmasters/deleteIntegerColumn?columnName=" + columnName + "&tableName='" + tableName + "'");

		MvcResult result = mockMvc.perform(getReq).andReturn();

		MockHttpServletResponse response2 = result.getResponse();

		int status = response2.getStatus();

		assertEquals(200, status);
	}

}
