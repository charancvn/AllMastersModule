package com.masters.accounting.finance.onpassive.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.masters.accounting.finance.onpassive.entity.AddColumnResoponse;
import com.masters.accounting.finance.onpassive.repository.RepositoryImpl;
import com.masters.accounting.finance.onpassive.service.AllMastersService;

@SpringBootTest
public class AllMastersServieImplTest {

	@Mock
	private RepositoryImpl repo;

	@Mock
	private AddColumnResoponse responseDTO;

	@InjectMocks
	private AllMastersService service;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getAllColumns() {

		List list = new ArrayList<>();
		AddColumnResoponse depOne = new AddColumnResoponse();
		list.add("column1");
		list.add("column1");
		String tableName = "aswaa";
		when(repo.getColumnsMasters(tableName)).thenReturn(list);
		List<AddColumnResoponse> notificationList = service.getColumnsMasters(tableName);
		assertEquals(2, notificationList.size());
	}

	@Test
	public void getAllColumnsWithOutParameter() {
		List list = new ArrayList<>();
		AddColumnResoponse depOne = new AddColumnResoponse();
		String tableName = "";
		when(repo.getColumnsMasters(tableName)).thenReturn(list);
		List<AddColumnResoponse> notificationList = service.getColumnsMasters(tableName);
		assertEquals(0, notificationList.size());

	}

	@Test
	public void addColumn() {
		AddColumnResoponse response = new AddColumnResoponse();
		response.setStatusCode(200);
		response.setStatusMessage("column added successfully!.");
		String tableName = "allmasters";
		String columName = "desc12";
		when(repo.addColumn(tableName, columName)).thenReturn(response);
		AddColumnResoponse save = service.createColumnMasters(tableName, columName);
		assertEquals(response, save);
	}
	
	@Test
	public void addIntegerColumn() {
		AddColumnResoponse response = new AddColumnResoponse();
		response.setStatusCode(200);
		response.setStatusMessage("column added successfully!.");
		String tableName = "allmasters";
		int columName = 2;
		when(repo.addIntegerColumn(tableName, columName)).thenReturn(response);
		AddColumnResoponse save = service.integerCreateColumnMasters(tableName, columName);
		assertEquals(response, save);
	}
	
	@Test
	public void updateColumn() {
		AddColumnResoponse response = new AddColumnResoponse();
		
		String tableName = "allmasters";
		String oldColumName = "desc12";
		String newColumName = "desc123";
		when(repo.updateColumn(tableName, oldColumName, newColumName)).thenReturn(response);
		AddColumnResoponse save = service.updateColumnMasters(tableName, oldColumName, newColumName);
		assertEquals(response, save);
	}
	@Test
	public void updateIntegerColumn() {
		AddColumnResoponse response = new AddColumnResoponse();
		
		String tableName = "allmasters";
		int oldColumName = 1;
		int newColumName = 2;
		when(repo.updateIntergerColumn(tableName, oldColumName, newColumName)).thenReturn(response);
		AddColumnResoponse save = service.updateIntergerColumnMasters(tableName, oldColumName, newColumName);
		assertEquals(response, save);
	}
	@Test
	public void deleteColumn() {
		AddColumnResoponse response = new AddColumnResoponse();
		
		String tableName = "allmasters";
		String columName = "desc12";
		when(repo.deleteColumn(tableName, columName)).thenReturn(response);
		AddColumnResoponse save = service.deleteColumnMasters(tableName, columName);
		assertEquals(response, save);
	}
	@Test
	public void deleteIntegerColumn() {
		AddColumnResoponse response = new AddColumnResoponse();
		
		String tableName = "allmasters";
		int columName = 2;
		when(repo.deleteIntergerColumn(tableName, columName)).thenReturn(response);
		AddColumnResoponse save = service.deleteIntergerColumnMasters(tableName, columName);
		assertEquals(response, save);
	}
}
