package com.masters.accounting.finance.onpassive.controller;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.CollectionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.masters.accounting.finance.onpassive.entity.AddColumnResoponse;
import com.masters.accounting.finance.onpassive.entity.GetAllGroupMastersResponse;
import com.masters.accounting.finance.onpassive.entity.GroupMasterResponse;
import com.masters.accounting.finance.onpassive.exception.ErrorDetails;
import com.masters.accounting.finance.onpassive.exception.ResourceNotFoundException;
import com.masters.accounting.finance.onpassive.request.MasterVO;
import com.masters.accounting.finance.onpassive.service.AllMastersService;
import com.masters.accounting.finance.onpassive.validation.Validation;

/**
 * 
 * @author SURYA & CHARAN
 *
 */
@RestController
@RequestMapping("/allmasters")
public class AllMastersController {

	@Autowired
	AllMastersService allMastersService;

	@Autowired
	private Validation validationUtil;

	/**
	 * 
	 * @param columnName
	 * @return
	 * @throws ResourceNotFoundException
	 */
	@PostMapping("/addcolumn")
	public ResponseEntity<?> addColumn(@RequestParam String tableName, @RequestParam String columnName)
			throws ResourceNotFoundException {
		System.out.println(" addColumnMasters  columnName  :" + columnName);
		if (tableName.equals("") || tableName == null) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "Table  name required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		if (columnName.equals("") || columnName == null) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column name required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		boolean columnNameExist = allMastersService.columnNameExist(tableName, columnName);
		System.out.println("columnNameExist ::::::::: " + columnNameExist);
		if (!columnNameExist) {
			AddColumnResoponse addColumnMasters = allMastersService.createColumnMasters(tableName, columnName);
			System.out.println(" addColumnMasters  :" + addColumnMasters);
			return new ResponseEntity<>(addColumnMasters, HttpStatus.OK);
		} else {

			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column name Already Exist ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}

	}

	/**
	 * 
	 * @param tableName
	 * @param columnName
	 * @return
	 * @throws ResourceNotFoundException
	 */
	@PostMapping("/addintegercolumn")
	public ResponseEntity<?> addIntergerColumn(@RequestParam String tableName, @RequestParam int columnName)
			throws ResourceNotFoundException {
		System.out.println(" addColumnMasters  columnName  :" + columnName);
		if (tableName.equals("") || tableName == null) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "Table  name required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		if (columnName == 0) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column name required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		boolean columnNameExist = allMastersService.integerColumnNameExist(tableName, columnName);
		System.out.println("columnNameExist ::::::::: " + columnNameExist);
		if (!columnNameExist) {
			AddColumnResoponse addColumnMasters = allMastersService.integerCreateColumnMasters(tableName, columnName);
			System.out.println(" addColumnMasters  :" + addColumnMasters);
			return new ResponseEntity<>(addColumnMasters, HttpStatus.OK);
		} else {

			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column name Already Exist ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}

	}

	/**
	 * 
	 * @param oldColumName
	 * @param newColumName
	 * @return
	 * @throws ResourceNotFoundException
	 */
	@PutMapping("/updateColumn")
	public ResponseEntity<?> updateColumn(@RequestParam String tableName, @RequestParam String oldColumName,
			@RequestParam String newColumName) throws ResourceNotFoundException {
		if (oldColumName.equals("") || oldColumName == null || newColumName.equals("") || newColumName == null) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column names required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		if (tableName.equals("") || oldColumName == null || newColumName.equals("") || newColumName == null) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column names required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		if (oldColumName.equals(newColumName)) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "Both Columns names are same ", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		AddColumnResoponse updateColumnMasters = allMastersService.updateColumnMasters(tableName, oldColumName,
				newColumName);
		return new ResponseEntity<AddColumnResoponse>(updateColumnMasters, new HttpHeaders(), HttpStatus.OK);
	}

	/**
	 * 
	 * @param tableName
	 * @param oldColumName
	 * @param newColumName
	 * @return
	 * @throws ResourceNotFoundException
	 */
	@PutMapping("/updateIntegerColumn")
	public ResponseEntity<?> updateIntergerColumn(@RequestParam String tableName, @RequestParam int oldColumName,
			@RequestParam int newColumName) throws ResourceNotFoundException {
		if (oldColumName == 0 || newColumName == 0) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column names required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		if (tableName.equals("") || oldColumName == 0 || newColumName == 0) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column names required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		if (oldColumName == newColumName) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "Both Columns names are same ", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		AddColumnResoponse updateColumnMasters = allMastersService.updateIntergerColumnMasters(tableName, oldColumName,
				newColumName);
		return new ResponseEntity<AddColumnResoponse>(updateColumnMasters, new HttpHeaders(), HttpStatus.OK);
	}

	/**
	 * 
	 * @param columnName
	 * @return
	 * @throws ResourceNotFoundException
	 */
	@GetMapping("/getColumns")
	public ResponseEntity<List<AddColumnResoponse>> getColumns(@RequestParam String tableName)
			throws ResourceNotFoundException {
		if (tableName.equals("") || tableName == null) {
			return new ResponseEntity<List<AddColumnResoponse>>(HttpStatus.BAD_REQUEST);
		}
		List<AddColumnResoponse> tableColumns = allMastersService.getColumnsMasters(tableName);
		return new ResponseEntity<List<AddColumnResoponse>>(tableColumns, new HttpHeaders(), HttpStatus.OK);
	}

	/**
	 * 
	 * @param columnName
	 * @return
	 * @throws ResourceNotFoundException
	 */
	@DeleteMapping("/deleteColumn")
	public ResponseEntity<?> deleteColumn(@RequestParam String tableName, @RequestParam String columnName)
			throws ResourceNotFoundException {
		if (columnName.equals("") || columnName == null) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column name required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		AddColumnResoponse updateColumnMasters = allMastersService.deleteColumnMasters(tableName, columnName);
		return new ResponseEntity<AddColumnResoponse>(updateColumnMasters, new HttpHeaders(), HttpStatus.OK);
	}

	@DeleteMapping("/deleteIntegerColumn")
	public ResponseEntity<?> deleteIntegerColumn(@RequestParam String tableName, @RequestParam int columnName)
			throws ResourceNotFoundException {
		if (columnName == 0) {
			ErrorDetails errorDetails = new ErrorDetails(new Date(), "column name required ...", "");
			return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
		}
		AddColumnResoponse updateColumnMasters = allMastersService.deleteIntergerColumnMasters(tableName, columnName);
		return new ResponseEntity<AddColumnResoponse>(updateColumnMasters, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/getwarehousebylocation")
	public ResponseEntity<List<AddColumnResoponse>> getWareHouseByLocation(@RequestParam String location)
			throws ResourceNotFoundException {
		if (location.equals("") || location == null) {
			return new ResponseEntity<List<AddColumnResoponse>>(HttpStatus.BAD_REQUEST);
		}
		List<AddColumnResoponse> tableColumns = allMastersService.getWaresHouseByLocation(location);
		return new ResponseEntity<List<AddColumnResoponse>>(tableColumns, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/save")
	public GroupMasterResponse addgroupMaster(@RequestBody MasterVO masterVO) {
		Set<String> errorMessages = validationUtil.validateAddMaster(masterVO);
		return !org.springframework.util.CollectionUtils.isEmpty(errorMessages)
				? new GroupMasterResponse(HttpStatus.PRECONDITION_FAILED, 500, errorMessages)
				: allMastersService.addGroupMaster(masterVO);

	}

	@GetMapping("/{id}")
	public GroupMasterResponse getgroupMaster(@PathVariable("id") int id) {
		Set<String> errorMessages = validationUtil.validateGetgroupMaster(id);

		return !org.springframework.util.CollectionUtils.isEmpty(errorMessages)
				? new GroupMasterResponse(HttpStatus.PRECONDITION_FAILED, 500, errorMessages)
				: allMastersService.getGroupMaster(id);
	}

	
	  @GetMapping("/")
	  public GetAllGroupMastersResponse getAllgroupMasters() {
	  return allMastersService.getAllGroupMasters();
	  
	  }
	 

	@PutMapping("/edit")
	public GroupMasterResponse editgroupMaster(@RequestBody MasterVO masterVO) {
		Set<String> errorMessages = validationUtil.validateEditMaster(masterVO);
		return !org.springframework.util.CollectionUtils.isEmpty(errorMessages)
				? new GroupMasterResponse(HttpStatus.PRECONDITION_FAILED, 500, errorMessages)
				: allMastersService.editGroupMaster(masterVO);
	}

	@DeleteMapping("/delete/{id}")
	public GroupMasterResponse deleteGroupMaster(@PathVariable("id") int id) {
		Set<String> errorMessages = validationUtil.validateDeleteGroupMaster(id);
		return !org.springframework.util.CollectionUtils.isEmpty(errorMessages)
				? new GroupMasterResponse(HttpStatus.PRECONDITION_FAILED, 500, errorMessages)
				: allMastersService.deleteGroupMasterById(id);

	}
}
