package com.masters.accounting.finance.onpassive.entity;

import java.util.List;
import java.util.Set;

import org.springframework.http.HttpStatus;

public class GetAllGroupMastersResponse extends AddColumnResoponse {

	private List<AllMasters> masters;

	public GetAllGroupMastersResponse() {

	}

	public GetAllGroupMastersResponse(HttpStatus status, int code, Set<String> errorMessages)

	{
		super.setStatus(status);
		super.setStatusCode(code);
		super.setErrorMessages(errorMessages);

	}

	public List<AllMasters> getMasters() {
		return masters;
	}

	public void setMasters(List<AllMasters> masters) {
		this.masters = masters;
	}

	

}
