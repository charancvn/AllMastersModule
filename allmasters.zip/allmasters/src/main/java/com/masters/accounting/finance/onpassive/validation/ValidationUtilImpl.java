package com.masters.accounting.finance.onpassive.validation;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.masters.accounting.finance.onpassive.request.MasterVO;

@Component
public class ValidationUtilImpl implements Validation {

	@Override
	public Set<String> validateAddMaster(MasterVO master) {
		Set<String> errorMessages = new HashSet<String>();
		addError(errorMessages, master.getMasterName(), "Master name cannot be empty");

		return errorMessages;
	}

	public static Set<String> addError(Set<String> errorMessages, String value, String errorMessage) {
		if (StringUtils.isEmpty(value)) {
			errorMessages.add(errorMessage);
		}
		return errorMessages;
	}

	public static Set<String> addError(Set<String> errorMessages, int value, String errorMessage) {

		if (value <= 0) {
			errorMessages.add(errorMessage);
		}
		return errorMessages;
	}
	
	@Override
	public Set<String> validateEditMaster(MasterVO master) {
		Set<String> errorMessages = new HashSet<String>();
		addError(errorMessages, master.getMasterName(), "Master name cannot be empty");

		return errorMessages;
	}

	@Override
	public Set<String> validateGetgroupMaster(int id) {
		Set<String> errorMessages = new HashSet<String>();
		addError(errorMessages, id, "Please enter valid GroupMaster id");
		return errorMessages;
	}

	@Override
	public Set<String> validateDeleteGroupMaster(int id) {
		Set<String> errorMessages = new HashSet<String>();
		addError(errorMessages, id, "Please enter valid GroupMaster id");
		return errorMessages;
	}

	

}
