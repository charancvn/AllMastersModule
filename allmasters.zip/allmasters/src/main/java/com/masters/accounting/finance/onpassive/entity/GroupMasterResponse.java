package com.masters.accounting.finance.onpassive.entity;

import java.util.Set;

import org.springframework.http.HttpStatus;

public class GroupMasterResponse extends AddColumnResoponse {

	private AllMasters master;

	public GroupMasterResponse() {

	}

	public GroupMasterResponse(HttpStatus status, int code, Set<String> errorMessages)

	{
		super.setStatus(status);
		super.setStatusCode(code);
		super.setErrorMessages(errorMessages);

	}

	public AllMasters getMaster() {
		return master;
	}

	public void setMaster(AllMasters master) {
		this.master = master;
	}

}
