package com.masters.accounting.finance.onpassive.entity;
import java.util.Set;

import org.springframework.http.HttpStatus;

public class AddColumnResoponse {

	private int statusCode;
	private HttpStatus status;
	private String statusMessage;
	private Set<String> errorMessages;
	
	
	public Set<String> getErrorMessages() {
		return errorMessages;
	}
	public void setErrorMessages(Set<String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public HttpStatus getStatus() {
		return status;
	}
	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "AddColumnResoponse [statusCode=" + statusCode + ", status=" + status + ", statusMessage="
				+ statusMessage + ", errorMessages=" + errorMessages + "]";
	}
	
	

	
}
