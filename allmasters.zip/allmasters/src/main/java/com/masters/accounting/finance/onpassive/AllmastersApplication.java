package com.masters.accounting.finance.onpassive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AllmastersApplication {

	public static void main(String[] args) {
		SpringApplication.run(AllmastersApplication.class, args);
	}

}
