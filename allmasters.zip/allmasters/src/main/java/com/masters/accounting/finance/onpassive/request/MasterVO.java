package com.masters.accounting.finance.onpassive.request;

public class MasterVO {

	private int id;
	private String masterName;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMasterName() {
		return masterName;
	}
	public void setMasterName(String masterName) {
		this.masterName = masterName;
	}
	@Override
	public String toString() {
		return "MasterVO [id=" + id + ", masterName=" + masterName + "]";
	}

	
}
