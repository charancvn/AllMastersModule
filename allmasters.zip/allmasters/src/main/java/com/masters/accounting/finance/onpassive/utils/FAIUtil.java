package com.masters.accounting.finance.onpassive.utils;

import com.masters.accounting.finance.onpassive.entity.AllMasters;
import com.masters.accounting.finance.onpassive.request.MasterVO;

public class FAIUtil {

	public static AllMasters loadMasterVOToMaster(MasterVO masterRequest) {
		AllMasters master = new AllMasters();
		master.setName(masterRequest.getMasterName());
		return master;
	}
}
