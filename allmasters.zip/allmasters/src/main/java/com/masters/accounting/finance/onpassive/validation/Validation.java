package com.masters.accounting.finance.onpassive.validation;

import java.util.Set;

import com.masters.accounting.finance.onpassive.request.MasterVO;

public interface Validation {

	Set<String> validateAddMaster(MasterVO master);

	Set<String> validateEditMaster(MasterVO master);

	Set<String> validateGetgroupMaster(int id);

	Set<String> validateDeleteGroupMaster(int id);

}
