package com.masters.accounting.finance.onpassive.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.masters.accounting.finance.onpassive.entity.AddColumnResoponse;
import com.masters.accounting.finance.onpassive.entity.AllMasters;
import com.masters.accounting.finance.onpassive.entity.GetAllGroupMastersResponse;
import com.masters.accounting.finance.onpassive.entity.GroupMasterResponse;
import com.masters.accounting.finance.onpassive.repository.GroupMasterRepository;
import com.masters.accounting.finance.onpassive.repository.RepositoryImpl;
import com.masters.accounting.finance.onpassive.repository.WareHouseMasterRepository;
import com.masters.accounting.finance.onpassive.request.MasterVO;
import com.masters.accounting.finance.onpassive.utils.FAIUtil;

/**
 * 
 * @author Surya AND Charan
 *
 */
@Service
public class AllMastersService {

	
	@Autowired
	private RepositoryImpl repositoryImpl;
	
	@Autowired
	private GroupMasterRepository groupMasterRepository;
	
	@Autowired
	WareHouseMasterRepository wareHouseMasterRepository;

	public AddColumnResoponse createColumnMasters(String tableName,String columnName) {
		return repositoryImpl.addColumn(tableName,columnName);
	}
	
	public AddColumnResoponse updateColumnMasters(String tableName,String oldColumName,String newColumName) {
		return repositoryImpl.updateColumn(tableName,oldColumName,newColumName);
	}
	
	public AddColumnResoponse deleteColumnMasters(String tableName,String columnName) {
		return repositoryImpl.deleteColumn(tableName,columnName);
	}
	public List<AddColumnResoponse> getColumnsMasters(String tableName) {
		return repositoryImpl.getColumnsMasters(tableName);
	}
	

	public boolean columnNameExist(String tableName,String columnName) {
		return repositoryImpl.columnNameExist(tableName,columnName);
	}

	public boolean integerColumnNameExist(String tableName, int columnName) {
		return repositoryImpl.integerColumnNameExist(tableName, columnName);
	}

	public AddColumnResoponse integerCreateColumnMasters(String tableName, int columnName) {

		return repositoryImpl.addIntegerColumn(tableName, columnName);
	}

	public AddColumnResoponse updateIntergerColumnMasters(String tableName, int oldColumName, int newColumName) {
		return repositoryImpl.updateIntergerColumn(tableName, oldColumName, newColumName);
	}

	public AddColumnResoponse deleteIntergerColumnMasters(String tableName, int columnName) {

		return repositoryImpl.deleteIntergerColumn(tableName, columnName);
	}

	public List<AddColumnResoponse> getWaresHouseByLocation(String location) {
		return repositoryImpl.getWaresHouseByLocation(location);
	}

	public GroupMasterResponse addGroupMaster(MasterVO allMasters) {

		List<AllMasters> list = groupMasterRepository.findByName(allMasters.getMasterName());
		GroupMasterResponse response = new GroupMasterResponse();
		if (CollectionUtils.isEmpty(list)) {
			AllMasters m=FAIUtil.loadMasterVOToMaster(allMasters);
			groupMasterRepository.save(m);
			response.setMaster(m);
			response.setStatusCode(200);
			response.setStatus(HttpStatus.OK);
		} else {
			response.setStatusCode(500);
			response.setStatus(HttpStatus.PRECONDITION_FAILED);
			response.setStatusMessage("Master already exist with the name :" + allMasters.getMasterName());
		}

		return response;
	}

	public GroupMasterResponse getGroupMaster(int id) {
		GroupMasterResponse response = new GroupMasterResponse();

		Optional<AllMasters> optional = groupMasterRepository.findById(id);
		if (optional.isPresent()) {

			response.setMaster(optional.get());
			response.setStatus(HttpStatus.OK);
			response.setStatusCode(200);
		} else {
			response.setStatusCode(500);
			response.setStatus(HttpStatus.PRECONDITION_FAILED);
			response.setStatusMessage("No Master found with specified id : " + id);
		}
		return response;
	}

	public GroupMasterResponse deleteGroupMasterById(int id) {
		GroupMasterResponse response = new GroupMasterResponse();
		Optional<AllMasters> optional = groupMasterRepository.findById(id);
		if (optional.isPresent()) {
			response.setMaster(optional.get());
			response.setStatus(HttpStatus.OK);
			response.setStatusCode(200);
			groupMasterRepository.deleteById(id);
		} else {
			response.setStatus(HttpStatus.PRECONDITION_FAILED);
			response.setStatusCode(500);
			response.setStatusMessage("No Master object found with the specified id : " + id);
		}
		return response;
	}

	public GetAllGroupMastersResponse getAllGroupMasters() {
		GetAllGroupMastersResponse response = new GetAllGroupMastersResponse();

		List<AllMasters> allMasters = groupMasterRepository.findAll();
		if (!CollectionUtils.isEmpty(allMasters)) {

			response.setMasters(allMasters);
			response.setStatus(HttpStatus.OK);
			response.setStatusCode(200);
		} else {
			response.setStatusCode(500);
			response.setStatus(HttpStatus.PRECONDITION_FAILED);
			response.setStatusMessage("Group Master is Empty");
		}
		return response;
	}
	
	public GroupMasterResponse editGroupMaster(MasterVO masterVO) {

		GroupMasterResponse response = new GroupMasterResponse();
		Optional<AllMasters> optional = groupMasterRepository.findById(masterVO.getId());
		if (optional.isPresent()) {
			AllMasters allMasters = optional.get();
			allMasters.setName(masterVO.getMasterName());
			response.setMaster(allMasters);
			response.setStatus(HttpStatus.OK);
			response.setStatusCode(200);
			groupMasterRepository.save(allMasters);

		} else {
			response.setStatus(HttpStatus.PRECONDITION_FAILED);
			response.setStatusCode(500);
			response.setStatusMessage("No Master object found with the specified id");
		}
		return response;
	}
	}

	

