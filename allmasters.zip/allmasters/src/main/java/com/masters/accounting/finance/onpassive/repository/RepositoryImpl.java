package com.masters.accounting.finance.onpassive.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.masters.accounting.finance.onpassive.entity.AddColumnResoponse;
import com.masters.accounting.finance.onpassive.entity.AllMasters;

/**
 * 
 * @author Surya And Charan
 *
 */
@Repository
public class RepositoryImpl {

	@Autowired
	private EntityManager em;

	public AddColumnResoponse addColumn(String tableName, String columName) {
		AddColumnResoponse response = new AddColumnResoponse();
		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = " ALTER TABLE " + tableName + " ADD " + columName + " varchar(255);";
		Query q = session.createNativeQuery(query);
		int i = q.executeUpdate();
		
		System.out.println("i======"+i);
		tx.commit();
		if (i == 0) {
			response.setStatusCode(200);
			response.setStatusMessage("column added successfully!.");
		} else {
			System.out.println("i inside else : "+i);
			response.setStatusCode(0);
			response.setStatusMessage("column addtion Failed!.");
		}

		return response;
	}
	
	public AddColumnResoponse addIntegerColumn(String tableName, int columName) {
		AddColumnResoponse response = new AddColumnResoponse();
		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = " ALTER TABLE " + tableName + " ADD " + columName + " INTEGER(255);";
		Query q = session.createNativeQuery(query);
		int i = q.executeUpdate();
		tx.commit();
		if (i == 0) {
			response.setStatusCode(200);
			response.setStatusMessage("column added successfully!.");
		} else {
			response.setStatusCode(0);
			response.setStatusMessage("column addtion Failed!.");
		}

		return response;
	}

	public AddColumnResoponse updateColumn(String tableName, String oldColumName, String newColumName) {
		AddColumnResoponse response = new AddColumnResoponse();
		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = " ALTER TABLE " + tableName + " RENAME COLUMN " + oldColumName + " TO " + newColumName;

		System.out.println("query in ==" + query);

		Query q = session.createNativeQuery(query);
		q.executeUpdate();
		tx.commit();
		return response;
	}
	
	public AddColumnResoponse updateIntergerColumn(String tableName, int oldColumName, int newColumName) {
		AddColumnResoponse response = new AddColumnResoponse();
		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = " ALTER TABLE " + tableName + " RENAME COLUMN " + oldColumName + " TO " + newColumName;

		System.out.println("query in ==" + query);

		Query q = session.createNativeQuery(query);
		q.executeUpdate();
		tx.commit();
		return response;
	}

	public AddColumnResoponse deleteColumn(String tableName, String columName) {
		AddColumnResoponse response = new AddColumnResoponse();
		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = " ALTER TABLE " + tableName + " DROP COLUMN " + columName;
		System.out.println("deleteColumn query====" + query);
		Query q = session.createNativeQuery(query);
		q.executeUpdate();
		tx.commit();
		return response;
	}
	
	public AddColumnResoponse deleteIntergerColumn(String tableName, int columName) {
		AddColumnResoponse response = new AddColumnResoponse();
		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = " ALTER TABLE " + tableName + " DROP COLUMN " + columName;
		System.out.println("deleteColumn query====" + query);
		Query q = session.createNativeQuery(query);
		q.executeUpdate();
		tx.commit();
		return response;
	}


	public List<AddColumnResoponse> getColumnsMasters(String tableName) {
		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = " SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME= " + " '" + tableName
				+ "' ";
		List<AddColumnResoponse> columns = session.createNativeQuery(query).list();

		tx.commit();

		return columns;
	}

	public boolean columnNameExist(String tableName, String columnName) {

		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='" + tableName + "';";
		List<String> columns = session.createNativeQuery(query).list();
		tx.commit();
		return columns.contains(columnName)?true:false;
		
	}
	
	public boolean integerColumnNameExist(String tableName, int columnName) {

		Session session = em.unwrap(Session.class);
		Transaction tx = session.beginTransaction();
		String query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='" + tableName + "';";
		List<String> columns = session.createNativeQuery(query).list();
		tx.commit();
		return columns.contains(columnName)?true:false;
		
	}

	public List<AddColumnResoponse> getWaresHouseByLocation(String location) {
		return null;
	}

	public List<AllMasters> findByMasterName(String masterName) {
		return null;
	}

	public void save(AllMasters m) {
		
	}

	public Optional<AllMasters> findById(int id) {
		return null;
	}

	public void deleteById(int id) {
		
	}

}
